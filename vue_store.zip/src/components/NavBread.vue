<template>
    <div class="nav-breadcrumb-wrap">
    <div class="container">
        <nav class="nav-breadcrumb">
        <a href="/">Home</a>
        <slot>
            <span>Goods</span>
        </slot>
        </nav>
    </div>
    </div>
</template>

<script>
    export default {
        data () {
            return {

            }
        },
        components: {

        }
    }
</script>

<style>
    .nav-breadcrumb {
        text-align: left;
    }
    .bread{
        height: 45px;
        line-height: 45px;
        background-color: #f0f0f0;
    }
    .bread-wrap{
        padding: 0 10px;
        font-size: 14px;
        color: #a1a1a1;
    }
    .bread-wrap a{
        position: relative;
        margin-right: 20px;
    }
    .bread-wrap a:after{
        position: absolute;
        top: 0px;
        content:'/';
        height:20px;
        line-height: 20px;
    }
    .bread-wrap span{
        color:#d1434a;
    }
</style>
